A directory for examples.
1. Put your new examples here. 
2. You can then run those examples by typing run example_file_name at the interpreter prompt.
