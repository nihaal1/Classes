The activity_main.xml and activity_main.java may be the files you will be modifying/editing. 
However, these two files will surely help you while working on the PocketCalculator lab.
